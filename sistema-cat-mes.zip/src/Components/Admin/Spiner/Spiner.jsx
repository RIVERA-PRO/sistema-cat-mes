import React from 'react';
import './Spiner.css';

export default function Spiner() {
    return (
        <div className='spinnerContainer'>
            <div className='spinner'>

                <p>Cargando...</p>
            </div>
        </div>
    );
}
