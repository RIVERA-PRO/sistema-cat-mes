const moneda = '$';

export default moneda;
