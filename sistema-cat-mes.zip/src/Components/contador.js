const contador = 20;

export default contador;
